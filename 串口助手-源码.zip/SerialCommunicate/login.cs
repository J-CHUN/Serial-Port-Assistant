﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SerialCommunicate
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "刘小纯" && textBox2.Text == "3118003167")
            {
                MessageBox.Show("欢迎登录系统！", "提示");
                this.Hide();
                Form1 form1 = new Form1();
                form1.Show();
            }
            else if(textBox1.Text == "刘小纯" && textBox2.Text != "3118003167")
            {
                MessageBox.Show("密码错误！", "提示");
            }
            else if (textBox1.Text != "刘小纯")
            {
                MessageBox.Show("该用户不存在！", "提示");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

       
    }
}
