﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SerialCommunicate
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());   
            //Application.Run(new login());  //若不需要登陆界面就把这个注释掉，取消上面的注释
        }
    }
}
