﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO.Ports;  //导入串口的命名空间

namespace SerialCommunicate
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);      //串口数据接收事件
            serialPort1.Encoding = Encoding.GetEncoding("GB2312");                                  //串口接收编码
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;                   //
        }

        private void Form1_Load(object sender, EventArgs e)   //窗口弹出触发
        {
            ovalShape1.FillColor = Color.Gray;
            SearchAndAddSerialToComboBox(serialPort1, comboBox1);
            comboBox2.Text = "115200";//默认波特率选择

        }


        private void button1_Click(object sender, EventArgs e)                                      //打开串口
        {
            try
            {
                serialPort1.PortName = comboBox1.Text;                                              //端口号           
                serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text);  //波特率                           
                serialPort1.Open();                                                                 //打开串口
                button1.Enabled = false;
                button2.Enabled = true;
                ovalShape1.FillColor = Color.Red;

            }
            catch
            {
                MessageBox.Show("串口打开错误或波特率设置有误", "小纯提示");
            }
        }

        private void button2_Click(object sender, EventArgs e)    //关闭串口
        {
            try
            {
                serialPort1.Close();                                                            //关闭串口        
                button1.Enabled = true;
                button2.Enabled = false;
                ovalShape1.FillColor = Color.Gray;
                comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;       //当点击关闭串口时，将波特率下拉列表设置为不可编辑
            }
            catch
            {
                MessageBox.Show("关闭串口错误！", "小纯提示");
            }
        }
        /*定义一个扫描可用端口的函数*/
        private void SearchAndAddSerialToComboBox(SerialPort MyPort, ComboBox MyBox)
        {                                                               //将可用端口号添加到ComboBox
            string Buffer;                                              //缓存
            MyBox.Items.Clear();                                        //清空ComboBox内容
            for (int i = 1; i < 20; i++)                                //循环
            {
                try                                                     //核心原理是依靠try和catch完成遍历
                {
                    Buffer = "COM" + i.ToString();
                    MyPort.PortName = Buffer;
                    MyPort.Open();                                      //如果失败，后面的代码不会执行
                    MyBox.Items.Add(Buffer);                            //打开成功，添加至下拉列表
                    MyPort.Close();                                     //关闭

                }
                catch
                {
                }
            }
            //MyBox.Text = MyString[0];                                   //初始化
        }



        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)             //串口接收事件
        {
            if (!radioButton3.Checked)
            {
                textBox1.AppendText(serialPort1.ReadExisting());                                //串口类会自动处理汉字，所以不需要特别转换
                if (checkBox3.Checked)
                {
                    textBox1.AppendText("  " + System.DateTime.Now.ToString("HH:mm:ss"));  //显示时间
                }

                if (checkBox2.Checked)
                    try
                    {
                        textBox1.AppendText(Environment.NewLine);  //接收自动换行
                    }

                    catch { }


            }
            else
            {
                byte[] data = new byte[serialPort1.BytesToRead];                                //定义缓冲区，因为串口事件触发时有可能收到不止一个字节
                serialPort1.Read(data, 0, data.Length);
                foreach (byte Member in data)                                                   //遍历用法
                {
                    string str = Convert.ToString(Member, 16).ToUpper();
                    textBox1.AppendText("0x" + (str.Length == 1 ? "0" + str : str) + " ");
                }
                if (checkBox3.Checked)
                {
                    textBox1.AppendText("  " + System.DateTime.Now.ToString("HH:mm:ss"));
                }
                if (checkBox2.Checked)
                    try
                    {
                        textBox1.AppendText(Environment.NewLine);
                    }

                    catch { }

            }
        }

        /*发送按键触发*/
        private void button3_Click(object sender, EventArgs e)
        {
            byte[] Data = new byte[1];                                                         //单字节发数据     
            if (serialPort1.IsOpen)
            {
                if (textBox2.Text != "")
                {
                    if (!radioButton1.Checked)
                    {
                        try
                        {
                            serialPort1.Write(textBox2.Text);
                            //serialPort1.WriteLine();                             //字符串写入


                        }
                        catch
                        {
                            MessageBox.Show("串口数据写入错误", "小纯提示");
                        }
                    }
                    else                                                                    //数据模式
                    {
                        try                                                                 //如果此时用户输入字符串中含有非法字符（字母，汉字，符号等等，try，catch块可以捕捉并提示）
                        {
                            for (int i = 0; i < (textBox2.Text.Length - textBox2.Text.Length % 2) / 2; i++)//转换偶数个
                            {
                                Data[0] = Convert.ToByte(textBox2.Text.Substring(i * 2, 2), 16);           //转换
                                serialPort1.Write(Data, 0, 1);
                            }
                            if (textBox2.Text.Length % 2 != 0)
                            {
                                Data[0] = Convert.ToByte(textBox2.Text.Substring(textBox2.Text.Length - 1, 1), 16);//单独处理最后一个字符
                                serialPort1.Write(Data, 0, 1);                              //写入
                            }
                            //Data = Convert.ToByte(textBox2.Text.Substring(textBox2.Text.Length - 1, 1), 16);
                            //  }
                        }
                        catch
                        {
                            MessageBox.Show("数据转换错误，请输入数字。", "小纯提示");
                        }
                    }
                }
            }
        }


        /*扫描按键触发*/
        private void button5_Click(object sender, EventArgs e)
        {
            SearchAndAddSerialToComboBox(serialPort1, comboBox1);       //扫描并将可用串口添加至下拉列表
        }


        /*清空按键触发*/
        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
        /*定时时间到*/
        private void timer1_Tick(object sender, EventArgs e)
        {

            button3_Click(button3, new EventArgs());  //调用发送按钮的回调函数
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                try
                {
                    //选择自动发送
                    numericUpDown1.Enabled = false;
                    timer1.Interval = (int)numericUpDown1.Value * 1000;
                    timer1.Start();
                }
                catch { }

            }
            else
            {
                try
                {
                    //选择不自动发送
                    numericUpDown1.Enabled = true;
                    // timer1.Interval = (int)numericUpDown1.Value;
                    timer1.Stop();
                }
                catch
                {
                    timer1.Stop();
                    MessageBox.Show("自动发送错误", "小纯提示");
                }
            }

        }


        private void button6_Click_1(object sender, EventArgs e)  //清空发送
        {
            textBox2.Clear();
        }

     

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)  //点击波特率设置列表
        {

            if (comboBox2.Text.Equals("custom"))      //当选择custom项时列表属性发生改变
            {


                try
                {
                    // comboBox2.DropDownStyle = ComboBoxStyle.DropDown;
                    comboBox2.DropDownStyle = ComboBoxStyle.Simple;
                    //  MessageBox.Show("先用其他波特率打开串口！", "小纯提示");

                }
                catch
                {

                    MessageBox.Show("设置波特率时错误！", "小纯提示");
                }
            }

        }

    }
}


